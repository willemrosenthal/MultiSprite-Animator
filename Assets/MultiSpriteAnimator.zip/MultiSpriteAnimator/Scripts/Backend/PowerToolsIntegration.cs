﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PowerTools {
public class PowerToolsIntegration : MonoBehaviour {
	// empty class that only exists so we can reference the powertools namespace
}
}
